# Texto a Voz (Android)

App que convierte lo que escribís en audio, con voz femenina o masculina.

## Qué hace
- Escribís o pegás un texto.
- Elegís voz **femenina** o **masculina** (y la velocidad).
- **Escuchar** para revisar errores antes de guardar; corregís el texto y volvés a escuchar.
- **Guardar audio**: queda en la lista "Mis audios" (archivo .wav) junto con su texto.
- Desde cada audio: **Oír**, **WhatsApp**, **Compartir** (cualquier app), **Corregir texto** y **Borrar**.

## Cómo obtener el APK
1. Subí esta carpeta a un repositorio de GitHub (rama `main`).
2. Entrá a la pestaña **Actions** del repo: se ejecuta solo "Compilar APK" (también podés lanzarlo con *Run workflow*).
3. Cuando termine (unos 3-5 minutos), abrí la ejecución y bajá **TextoAVoz-apk** al final de la página.
4. Descomprimí, pasá `app-debug.apk` al celular e instalalo (hay que permitir "instalar apps desconocidas").

## Requisitos en el celular
- Android 7.0 o superior.
- Un motor de voz instalado (casi todos traen "Servicios de voz de Google").
  Para más voces: Ajustes > Sistema > Idiomas > Salida de texto a voz.
