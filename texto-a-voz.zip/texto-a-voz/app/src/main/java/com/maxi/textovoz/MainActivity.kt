package com.maxi.textovoz

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var voiceList: List<Voice> = emptyList()
    private var speechLocale: Locale = Locale.getDefault()
    private var player: MediaPlayer? = null

    private lateinit var etText: EditText
    private lateinit var rbFemale: RadioButton
    private lateinit var rbMale: RadioButton
    private lateinit var spVoice: Spinner
    private lateinit var sbSpeed: SeekBar
    private lateinit var tvSpeed: TextView
    private lateinit var btnListen: Button
    private lateinit var btnStop: Button
    private lateinit var btnSave: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var llSaved: LinearLayout

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etText = findViewById(R.id.etText)
        rbFemale = findViewById(R.id.rbFemale)
        rbMale = findViewById(R.id.rbMale)
        spVoice = findViewById(R.id.spVoice)
        sbSpeed = findViewById(R.id.sbSpeed)
        tvSpeed = findViewById(R.id.tvSpeed)
        btnListen = findViewById(R.id.btnListen)
        btnStop = findViewById(R.id.btnStop)
        btnSave = findViewById(R.id.btnSave)
        tvStatus = findViewById(R.id.tvStatus)
        tvEmpty = findViewById(R.id.tvEmpty)
        llSaved = findViewById(R.id.llSaved)

        sbSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                tvSpeed.text = String.format(Locale.US, "Velocidad: %.1fx", speechRate())
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnListen.setOnClickListener { preview() }
        btnStop.setOnClickListener { stopAll() }
        btnSave.setOnClickListener { saveAudio() }

        tts = TextToSpeech(this, this)
        refreshSavedList()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        player?.release()
        player = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- motor de voz

    override fun onInit(status: Int) {
        val engine = tts
        if (status != TextToSpeech.SUCCESS || engine == null) {
            setStatus("No se pudo iniciar el motor de voz. Instalá \"Servicios de voz de Google\" desde Play Store.")
            return
        }

        val candidates = listOf(
            Locale("es", "AR"),
            Locale("es", "US"),
            Locale("es", "ES"),
            Locale("es"),
            Locale.getDefault()
        )
        speechLocale = candidates.firstOrNull {
            engine.isLanguageAvailable(it) >= TextToSpeech.LANG_AVAILABLE
        } ?: Locale.getDefault()
        engine.setLanguage(speechLocale)
        engine.setOnUtteranceProgressListener(utteranceListener)

        loadVoices()
        ttsReady = true
        setStatus("Listo para usar.")
    }

    private fun loadVoices() {
        val all: List<Voice> = try {
            tts?.voices?.toList() ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }

        voiceList = all
            .filter { it.locale.language == speechLocale.language }
            .filter { !(it.features ?: emptySet<String>()).contains("notInstalled") }
            .sortedBy { it.name }

        val labels = mutableListOf("Automática")
        voiceList.forEachIndexed { index, voice ->
            val country = if (voice.locale.country.isNullOrEmpty()) "--" else voice.locale.country
            val online = if (voice.isNetworkConnectionRequired) ", online" else ""
            labels.add("Voz ${index + 1} ($country$online)")
        }
        spVoice.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
    }

    /** true = femenina, false = masculina, null = el sistema no lo indica. */
    private fun genderOf(voice: Voice): Boolean? {
        val name = voice.name.lowercase(Locale.ROOT)
        return when {
            name.contains("female") || name.contains("fem") -> true
            name.contains("male") || name.contains("masc") -> false
            else -> null
        }
    }

    private fun speechRate(): Float = 0.5f + sbSpeed.progress / 100f

    /** Configura voz, tono y velocidad según lo elegido en pantalla. */
    private fun applyVoice() {
        val engine = tts ?: return
        engine.setSpeechRate(speechRate())

        val selected = spVoice.selectedItemPosition
        if (selected > 0 && selected - 1 < voiceList.size) {
            engine.setVoice(voiceList[selected - 1])
            engine.setPitch(1.0f)
            return
        }

        val female = rbFemale.isChecked
        val byName = voiceList.firstOrNull { genderOf(it) == female }
        if (byName != null) {
            engine.setVoice(byName)
            engine.setPitch(1.0f)
        } else {
            val default = engine.defaultVoice
            if (default != null && default.locale.language == speechLocale.language) {
                engine.setVoice(default)
            } else {
                engine.setLanguage(speechLocale)
            }
            engine.setPitch(if (female) 1.15f else 0.75f)
        }
    }

    private val utteranceListener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}

        override fun onDone(utteranceId: String?) {
            if (utteranceId != null && utteranceId.startsWith("save:")) {
                runOnUiThread {
                    btnSave.isEnabled = true
                    setStatus("Audio guardado ✔")
                    refreshSavedList()
                }
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            if (utteranceId != null && utteranceId.startsWith("save:")) {
                val base = utteranceId.removePrefix("save:")
                File(audioDir(), "$base.wav").delete()
                File(audioDir(), "$base.txt").delete()
                runOnUiThread {
                    btnSave.isEnabled = true
                    setStatus("No se pudo generar el audio.")
                    refreshSavedList()
                }
            } else {
                runOnUiThread { setStatus("Error al reproducir la voz.") }
            }
        }
    }

    // ---------------------------------------------------------------- acciones principales

    private fun checkReady(text: String): Boolean {
        if (!ttsReady) {
            toast("El motor de voz todavía no está listo")
            return false
        }
        if (text.isEmpty()) {
            toast("Escribí algo primero")
            return false
        }
        val max = TextToSpeech.getMaxSpeechInputLength()
        if (text.length > max) {
            toast("El texto es muy largo (máximo $max caracteres). Dividilo en partes.")
            return false
        }
        return true
    }

    private fun preview() {
        val text = etText.text.toString().trim()
        if (!checkReady(text)) return
        stopAll()
        applyVoice()
        setStatus("Reproduciendo… (corregí el texto y volvé a escuchar si hace falta)")
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "preview")
    }

    private fun stopAll() {
        tts?.stop()
        player?.release()
        player = null
    }

    private fun saveAudio() {
        val text = etText.text.toString().trim()
        if (!checkReady(text)) return
        stopAll()
        applyVoice()

        val dir = audioDir()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val base = "${stamp}_${slug(text)}"
        val wav = File(dir, "$base.wav")

        val result = tts?.synthesizeToFile(text, Bundle(), wav, "save:$base")
        if (result != TextToSpeech.SUCCESS) {
            toast("No se pudo generar el audio")
            return
        }
        try {
            File(dir, "$base.txt").writeText(text)
        } catch (e: Exception) {
            // Si falla el texto, el audio igual se guarda.
        }
        btnSave.isEnabled = false
        setStatus("Generando audio…")
    }

    // ---------------------------------------------------------------- lista de audios guardados

    private fun audioDir(): File {
        val root = getExternalFilesDir(null) ?: filesDir
        val dir = File(root, "audios")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun slug(text: String): String {
        val plain = Normalizer.normalize(text.take(30), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}"), "")
        val clean = plain.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_')
        return if (clean.isEmpty()) "audio" else clean
    }

    private fun refreshSavedList() {
        llSaved.removeAllViews()
        val files = audioDir().listFiles()
            ?.filter { it.extension == "wav" }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
        tvEmpty.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
        for (file in files) {
            llSaved.addView(buildRow(file))
        }
    }

    private fun buildRow(wav: File): View {
        val txt = File(wav.parentFile, wav.nameWithoutExtension + ".txt")
        val snippet = try {
            if (txt.exists()) txt.readText().replace("\n", " ").take(70) else wav.name
        } catch (e: Exception) {
            wav.name
        }
        val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
            .format(Date(wav.lastModified()))

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        box.addView(TextView(this).apply {
            text = snippet
            textSize = 16f
        })
        box.addView(TextView(this).apply {
            text = date
            textSize = 12f
            setTextColor(0xFF666666.toInt())
        })

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(smallButton("▶ Oír") { playSaved(wav) })
        row1.addView(smallButton("WhatsApp") { share(wav, true) })
        row1.addView(smallButton("Compartir") { share(wav, false) })

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(smallButton("✏ Corregir texto") { loadTextForEditing(txt) })
        row2.addView(smallButton("🗑 Borrar") { confirmDelete(wav, txt) })

        box.addView(row1)
        box.addView(row2)
        return box
    }

    private fun smallButton(label: String, onClick: () -> Unit): Button {
        val button = Button(this, null, android.R.attr.buttonBarButtonStyle)
        button.text = label
        button.isAllCaps = false
        button.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        button.setOnClickListener { onClick() }
        return button
    }

    private fun playSaved(file: File) {
        stopAll()
        try {
            val mp = MediaPlayer()
            mp.setDataSource(file.absolutePath)
            mp.setOnCompletionListener {
                it.release()
                if (player === it) player = null
            }
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            toast("No se pudo reproducir el audio")
        }
    }

    private fun share(file: File, whatsapp: Boolean) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "audio/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("audio", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        if (whatsapp) {
            for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
                try {
                    send.setPackage(pkg)
                    startActivity(send)
                    return
                } catch (e: ActivityNotFoundException) {
                    // probamos con el siguiente
                }
            }
            send.setPackage(null)
            toast("No encontré WhatsApp, elegí otra app")
        }
        startActivity(Intent.createChooser(send, "Compartir audio"))
    }

    private fun loadTextForEditing(txt: File) {
        if (!txt.exists()) {
            toast("Este audio no tiene texto guardado")
            return
        }
        try {
            etText.setText(txt.readText())
            etText.setSelection(etText.text.length)
            findViewById<ScrollView>(R.id.scrollMain).smoothScrollTo(0, 0)
            setStatus("Texto cargado. Corregilo, escuchalo y guardalo de nuevo.")
        } catch (e: Exception) {
            toast("No se pudo leer el texto")
        }
    }

    private fun confirmDelete(wav: File, txt: File) {
        AlertDialog.Builder(this)
            .setMessage("¿Borrar este audio?")
            .setPositiveButton("Borrar") { _, _ ->
                wav.delete()
                txt.delete()
                refreshSavedList()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------------------------------------------------------------- utilidades

    private fun setStatus(message: String) {
        tvStatus.text = message
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
